interface SendNewHolidayRequestRequestInterface {
  userId: number;
  startDate: string;
  endDate: string;
  type: string;
}

export interface SendNewHolidayRequestResponseInterface {
  guid: string;
}

async function sendNewHolidayRequest(props: SendNewHolidayRequestRequestInterface): Promise<Response> {
  const dataBase: SendNewHolidayRequestResponseInterface = { guid: "AAAAAA" };

  return new Response(JSON.stringify(dataBase));
}
export default sendNewHolidayRequest;
