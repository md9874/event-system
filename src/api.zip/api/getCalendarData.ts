export type GetCalendarDataPersonDispositionKindType = "holiday" | "office" | "homework" | "sick";

export interface GetCalendarDataPersonDispositionInterface {
  startHour: number;
  startMinutes: number;
  endHour: number;
  endMinutes: number;
  date: string;
  kind: GetCalendarDataPersonDispositionKindType;
}

export interface GetCalendarDataPersonInterface {
  name: string;
  schedules: GetCalendarDataPersonDispositionInterface[];
}

export interface GetCalendarDataInterface {
  departmentName: string;
  persons: GetCalendarDataPersonInterface[];
}

async function getCalendarData(): Promise<Response> {
  const dataBase: GetCalendarDataInterface[] = [
    {
      departmentName: "Handlowy",
      persons: [
        {
          name: "Jan Kowalski",
          schedules: [
            {
              startHour: 9,
              startMinutes: 0,
              endHour: 17,
              endMinutes: 0,
              date: "2023-12-01T00:00:00",
              kind: "holiday",
            },
            {
              startHour: 9,
              startMinutes: 0,
              endHour: 17,
              endMinutes: 0,
              date: "2023-12-02T00:00:00",
              kind: "office",
            },
            {
              startHour: 7,
              startMinutes: 0,
              endHour: 15,
              endMinutes: 0,
              date: "2023-12-03T00:00:00",
              kind: "homework",
            },
            {
              startHour: 7,
              startMinutes: 0,
              endHour: 15,
              endMinutes: 0,
              date: "2023-12-04T00:00:00",
              kind: "sick",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-05T00:00:00",
              kind: "office",
            },
          ],
        },
        {
          name: "Piotr Nowak",
          schedules: [
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-01T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-02T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-03T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-04T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-05T00:00:00",
              kind: "office",
            },
          ],
        },
      ],
    },
    {
      departmentName: "Księgowość",
      persons: [
        {
          name: "Jan Kowalski",
          schedules: [
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-01T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-02T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-03T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-04T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-05T00:00:00",
              kind: "office",
            },
          ],
        },
        {
          name: "Piotr Nowak",
          schedules: [
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-01T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-02T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-03T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-04T00:00:00",
              kind: "office",
            },
            {
              startHour: 8,
              startMinutes: 0,
              endHour: 16,
              endMinutes: 0,
              date: "2023-12-05T00:00:00",
              kind: "office",
            },
          ],
        },
      ],
    },
  ];

  return new Response(JSON.stringify(dataBase));
}
export default getCalendarData;
