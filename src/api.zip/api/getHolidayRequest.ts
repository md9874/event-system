interface GetHolidayRequestRequestInterface {
  holidayRequestId: number;
}

export interface GetHolidayRequestResponseInterface {
  id: number;
  createdById: number;
  createdBy: string;
  typeId: number;
  typeName: string;
  dateFrom: string;
  dateTo: string;
  daysCount: number;
  statusId: number;
  statusName: string;
  statusComment: string;
  lastModifyById: number;
  lastModifyByName: string;
  lastModifyDate: string;
  isClosed: boolean;
}

async function getHolidayRequest(props: GetHolidayRequestRequestInterface): Promise<Response> {
  const dataBase: GetHolidayRequestResponseInterface = {
    id: 1,
    createdById: 1,
    createdBy: "Jan Kowal",
    typeId: 1,
    typeName: "urlop",
    dateFrom: "2023-07-12T00:00:00",
    dateTo: "2023-07-24T00:00:00",
    daysCount: 9,
    statusId: 1,
    statusName: "otwarty",
    statusComment: "Przesłano do zatwierdzenia",
    lastModifyById: 2,
    lastModifyByName: "Jan Kowalski",
    lastModifyDate: "2023-07-08T13:15:42",
    isClosed: true,
  };

  return new Response(JSON.stringify(dataBase));
}
export default getHolidayRequest;
