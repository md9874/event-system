export interface GetMyHolidayRequestsRequestInterface {
  userId: number;
}

export interface GetMyHolidayRequestsResponseInterface {
  id: number;
  createdById: number;
  createdBy: string;
  typeId: number;
  typeName: string;
  dateFrom: string;
  dateTo: string;
  daysCount: number;
  statusId: number;
  statusName: string;
  statusComment: string;
  lastModifyById: number;
  lastModifyByName: string;
  lastModifyDate: string;
  isClosed: boolean;
}

async function getMyHolidayRequests(props: GetMyHolidayRequestsRequestInterface): Promise<Response> {
  const dataBase: GetMyHolidayRequestsResponseInterface[] = [
    {
      id: 1,
      createdById: 1,
      createdBy: "Jan Kowal",
      typeId: 1,
      typeName: "urlop",
      dateFrom: "2023-07-12T00:00:00",
      dateTo: "2023-07-24T00:00:00",
      daysCount: 9,
      statusId: 1,
      statusName: "otwarty",
      statusComment: "Przesłano do zatwierdzenia",
      lastModifyById: 2,
      lastModifyByName: "Jan Kowalski",
      lastModifyDate: "2023-07-08T13:15:42",
      isClosed: true,
    },
    {
      id: 2,
      typeId: 1,
      createdById: 1,
      createdBy: "Jan Kowal",
      typeName: "urlop",
      dateFrom: "2023-06-12T00:00:00",
      dateTo: "2023-06-24T00:00:00",
      daysCount: 9,
      statusId: 1,
      statusName: "przyjęty",
      statusComment: "Zatwierdzono",
      lastModifyById: 2,
      lastModifyByName: "Jan Kowalski",
      lastModifyDate: "2023-06-08T13:15:42",
      isClosed: true,
    },
    {
      id: 3,
      typeId: 1,
      createdById: 2,
      createdBy: "Jan Kowal",
      typeName: "urlop",
      dateFrom: "2023-06-12T00:00:00",
      dateTo: "2023-06-24T00:00:00",
      daysCount: 9,
      statusId: 1,
      statusName: "przyjęty",
      statusComment: "Zatwierdzono",
      lastModifyById: 2,
      lastModifyByName: "Jan Kowalski",
      lastModifyDate: "2023-06-08T13:15:42",
      isClosed: true,
    },
    {
      id: 4,
      typeId: 1,
      createdById: 1,
      createdBy: "Jan Kowal",
      typeName: "urlop",
      dateFrom: "2023-06-12T00:00:00",
      dateTo: "2023-06-24T00:00:00",
      daysCount: 9,
      statusId: 2,
      statusName: "przyjęty",
      statusComment: "Zatwierdzono",
      lastModifyById: 2,
      lastModifyByName: "Jan Kowalski",
      lastModifyDate: "2023-06-08T13:15:42",
      isClosed: true,
    },
  ];

  return new Response(JSON.stringify(dataBase));
}
export default getMyHolidayRequests;
