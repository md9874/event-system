import { FormFieldKindType, SelectValueInterface } from "types";

interface SendFormResolutRequestInterface {
  id: number | undefined;
  value: string | number | boolean | undefined;
}

async function sendFormResolut(props: SendFormResolutRequestInterface[]): Promise<Response> {
  return new Response(JSON.stringify(null));
}
export default sendFormResolut;
