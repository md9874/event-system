export interface GetHolidayRequestTypesResponseInterface {
  name: string;
  id: number;
}

async function getHolidayRequestTypes(): Promise<Response> {
  const dataBase: GetHolidayRequestTypesResponseInterface[] = [
    {
      name: "urlop",
      id: 1,
    },
    {
      name: "zwolnienie",
      id: 2,
    },
  ];

  return new Response(JSON.stringify(dataBase));
}
export default getHolidayRequestTypes;
