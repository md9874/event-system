interface GetHolidayRequestAttachmentsRequestInterface {
  holidayRequestId: number;
}

export interface GetHolidayRequestAttachmentsResponseInterface {
  id: number;
  name: string;
  sourcePath: string;
}

async function getHolidayRequestAttachments(props: GetHolidayRequestAttachmentsRequestInterface): Promise<Response> {
  const dataBase: GetHolidayRequestAttachmentsResponseInterface[] = [
    {
      id: 1,
      name: "Pierwszy załącznik.jpg",
      sourcePath: "https://cdn.pixabay.com/photo/2023/08/15/16/55/motorcycle-8192323_960_720.jpg",
    },
    {
      id: 2,
      name: "Drugi załącznik.jpg",
      sourcePath: "https://cdn.pixabay.com/photo/2023/02/04/21/32/flowers-7768218_960_720.jpg",
    },
  ];

  return new Response(JSON.stringify(dataBase));
}

export default getHolidayRequestAttachments;
