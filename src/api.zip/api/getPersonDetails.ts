export interface GetPersonDetailsRequestInterface {
  userId: number;
}

export interface GetPersonDetailsResponseInterface {
  numberOfDaysLeft: number;
}

async function getPersonDetails(props: GetPersonDetailsRequestInterface[]): Promise<Response> {
  const serverResponse: GetPersonDetailsResponseInterface = {
    numberOfDaysLeft: 3,
  };

  return new Response(JSON.stringify(serverResponse));
}
export default getPersonDetails;
