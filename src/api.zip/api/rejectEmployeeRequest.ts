interface RejectEmployeeRequestRequestInterface {
  holidayRequestId: number;
}

async function rejectEmployeeRequest(props: RejectEmployeeRequestRequestInterface): Promise<Response> {
  return new Response(JSON.stringify(null));
}

export default rejectEmployeeRequest;
