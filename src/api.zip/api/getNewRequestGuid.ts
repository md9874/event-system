export interface GetNewRequestGuidRequestInterface {
  userId: number;
}

export interface GetNewRequestGuidResponseInterface {
  guid: string;
}

async function getNewRequestGuid(props: GetNewRequestGuidRequestInterface): Promise<Response> {
  const serverResponse: GetNewRequestGuidResponseInterface = {
    guid: "GUIDAAAAAA",
  };

  return new Response(JSON.stringify(serverResponse));
}
export default getNewRequestGuid;
