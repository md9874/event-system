import { proxy } from "../appConfig";

import { UserRoleType } from "types";

export interface LoginRequestInterface {
  login: string;
  password: string;
}

export interface LoginResponseInterface {
  id: number;
  userName: string;
  login: string;
  role: UserRoleType;
  email: string;
  hasResetedPassword: boolean;
}

async function login(props: LoginRequestInterface): Promise<Response> {
  let serverResponse = await fetch(`${proxy}/Authenticate/Authenticate`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      login: props.login,
      password: props.password,
    }),
  });
  console.log("serverResponse", serverResponse);
  //return serverResponse;

  /*if (props.login && props.password.toString() === "123") {
    const serverResponse: LoginResponseInterface = {
      id: 1,
      userName: "Robert Fiołek",
      login: "bt.rf",
      role: "hr",
      email: "rf@example.com",
      hasResetedPassword: false,
    };
    return new Response(JSON.stringify(serverResponse));
  } else {
    return new Response(new Blob(), { status: 500 });
  }*/
  const serverResponsee: LoginResponseInterface = {
    id: 1,
    userName: "Robert Fiołek",
    login: "bt.rf",
    role: "hr",
    email: "rf@example.com",
    hasResetedPassword: false,
  };
  return new Response(JSON.stringify(serverResponsee));
}

export default login;
