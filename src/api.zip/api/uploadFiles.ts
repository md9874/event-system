export interface UploadFileRequestInterface {
  pictures: File[];
}

export interface UploadFileResponseInterface {}

async function uploadFiles(props: UploadFileRequestInterface): Promise<Response> {
  const serverResponse: UploadFileResponseInterface = {};
  return new Response(JSON.stringify(serverResponse));
}
export default uploadFiles;
