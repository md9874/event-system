export interface RemoveAttachmentFromRequestResponseInterface {
  holidayRequestId: number;
  attachmentId: number;
}

async function removeAttachmentFromRequest(props: RemoveAttachmentFromRequestResponseInterface): Promise<Response> {
  const myBlob = new Blob();
  let myOptions;

  if (props.holidayRequestId === 1) {
    myOptions = { status: 200, statusText: "SuperSmashingGreat!" };
  } else {
    myOptions = { status: 404, statusText: "Something gone wrong!" };
  }

  return new Response(myBlob, myOptions);
}
export default removeAttachmentFromRequest;
