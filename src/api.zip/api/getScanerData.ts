export interface GetScanerDataRequestInterface {
  guid: string;
}

export interface GetScanerDataResponseInterface {
  numberOfPictures: number;
}

async function getScanerData(props: GetScanerDataRequestInterface): Promise<Response> {
  const serverResponse: GetScanerDataResponseInterface = {
    numberOfPictures: 3,
  };

  let myOptions;

  if (props.guid === "GUIDAAAAAA") {
    myOptions = { status: 200, statusText: "SuperSmashingGreat!" };
  } else {
    myOptions = { status: 404, statusText: "Something gone wrong!" };
  }

  return new Response(JSON.stringify(serverResponse), myOptions);
}
export default getScanerData;
