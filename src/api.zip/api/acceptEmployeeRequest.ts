interface AcceptEmployeeRequestRequestInterface {
  holidayRequestId: number;
}

async function acceptEmployeeRequest(props: AcceptEmployeeRequestRequestInterface): Promise<Response> {
  return new Response(JSON.stringify(null));
}

export default acceptEmployeeRequest;
