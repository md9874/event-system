interface GetHolidayRequestHistoryRequestInterface {
  holidayRequestId: number;
}

export interface GetHolidayRequestHistoryResponseInterface {
  statusName: string;
  modifiedBy: string;
  modifiedDate: string;
}

async function getHolidayRequestHistory(props: GetHolidayRequestHistoryRequestInterface): Promise<Response> {
  const dataBase: GetHolidayRequestHistoryResponseInterface[] = [
    {
      statusName: "otwarty",
      modifiedBy: "Jan Nowak",
      modifiedDate: "2023-06-08T13:15:42",
    },
    {
      statusName: "zaakceptowany",
      modifiedBy: "Piotr Kowalski",
      modifiedDate: "2023-06-08T13:15:42",
    },
  ];

  return new Response(JSON.stringify(dataBase));
}
export default getHolidayRequestHistory;
