import { FormFieldKindType, SelectValueInterface } from "types";

export interface GetFormFieldsDataResponseInterface {
  id?: number;
  type: FormFieldKindType;
  label?: string;
  required?: boolean;
  helperText?: string;
  items?: SelectValueInterface[];
}

async function getFormFieldsData(): Promise<Response> {
  const dataBase: GetFormFieldsDataResponseInterface[] = [
    {
      id: 1,
      type: "checkbox",
      label: "checkbox",
      helperText: "checkbox-helpertext",
      items: [],
    },
    {
      type: "br",
    },
    {
      id: 2,
      type: "date",
      label: "date",
      helperText: "date-helpertext",
      items: [],
    },
    {
      id: 3,
      type: "datetime",
      label: "datetime",
      helperText: "datetime-helpertext",
      items: [],
    },
    {
      id: 9,
      type: "time",
      label: "time",
      helperText: "time-helpertext",
      items: [],
    },
    {
      type: "br",
    },
    {
      id: 8,
      type: "textfield",
      label: "textfield",
      helperText: "textfield-helpertext",
      items: [],
    },
    {
      id: 5,
      type: "password",
      label: "password",
      helperText: "password-helpertext",
      items: [],
    },
    {
      id: 10,
      type: "textfield-multiline",
      label: "textfield-multiline",
      helperText: "textfield-multiline-helpertext",
      items: [],
    },
    {
      type: "br",
    },
    {
      id: 6,
      type: "radio",
      label: "radio",
      helperText: "radio-helpertext",
      items: [
        { name: "first", value: 1 },
        { name: "second", value: 2 },
      ],
    },
    {
      type: "br",
    },
    {
      id: 7,
      type: "select",
      label: "select",
      helperText: "select-helpertext",
      items: [
        { name: "first", value: 1 },
        { name: "second", value: 2 },
      ],
    },
    {
      id: 4,
      type: "number",
      label: "number",
      helperText: "number-helpertext",
      items: [],
    },
  ];

  return new Response(JSON.stringify(dataBase));
}
export default getFormFieldsData;
